package com.orx.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Receives the updated version data (as JSON) from the Version Updates
 * admin page and writes it directly to the NAS data directory that the
 * public Versions page reads from — no manual download/copy step needed.
 *
 * Mapped in web.xml to /products/version-updates/save, which falls under
 * the existing /products/* security-constraint, so this is automatically
 * gated behind the same LDAP login as the rest of the admin area — no
 * separate auth check needed here.
 *
 * Lives in $CATALINA_HOME/lib (like LdapMemberRealm), NOT inside the WAR,
 * so it survives WAR redeploys without needing to be rebuilt/repackaged
 * each time the site changes.
 */
public class VersionsUpdateServlet extends HttpServlet {

    // Matches the NAS path mounted via <Resources><PostResources .../></Resources>
    // in ROOT.xml — writing here makes the change visible at /data/versions.json
    // immediately, no restart needed.
    private static final String OUTPUT_PATH = "/wasnas/Website/mdw/tomcat/data/versions.json";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        StringBuilder body = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line).append('\n');
            }
        }

        String json = body.toString().trim();

        // Minimal sanity check — this isn't full JSON validation, just a
        // guard against writing something obviously wrong (empty body,
        // HTML error page, etc.) over a good file.
        if (json.isEmpty() || !(json.startsWith("[") || json.startsWith("{"))) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"Request body does not look like JSON\"}");
            return;
        }

        try {
            Path outputPath = Paths.get(OUTPUT_PATH);
            Files.createDirectories(outputPath.getParent());
            Files.write(outputPath, json.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            return;
        }

        resp.setStatus(HttpServletResponse.SC_OK);
        resp.getWriter().write("{\"status\":\"ok\"}");
    }
}
