package com.orx.realm;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.catalina.realm.GenericPrincipal;
import org.apache.catalina.realm.RealmBase;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

/**
 * Minimal LDAP Realm that authenticates and resolves roles using plain JNDI
 * calls modeled directly on a standalone test that was confirmed to work
 * against this environment's Active Directory — after stock JNDIRealm
 * (both roleBase/roleSearch and userRoleAttribute="memberOf" variants)
 * consistently failed to resolve roles despite identical underlying data
 * being reachable and correct.
 *
 * XML attributes (set on <Realm className="com.orx.realm.LdapMemberRealm" ...>):
 *   connectionURL      e.g. ldap://ad-ldap-app.uhc.com:389
 *   connectionName     bind DN of the service account
 *   connectionPassword bind password
 *   userBase           base DN to search for users
 *   userSearch         filter with {0} = username, e.g. (sAMAccountName={0})
 *   roleBase           base DN to search for groups
 *   roleSearchFilter   filter with {0} = user's DN,
 *                      e.g. (&(objectClass=group)(member={0}))
 *   roleNameAttribute  attribute holding the role's short name, e.g. cn
 *   referrals          "follow" (recommended for AD), "ignore", or "throw"
 */
public class LdapMemberRealm extends RealmBase {

    private static final Log log = LogFactory.getLog(LdapMemberRealm.class);

    private String connectionURL;
    private String connectionName;
    private String connectionPassword;
    private String userBase;
    private String userSearch = "(sAMAccountName={0})";
    private String roleBase;
    private String roleSearchFilter = "(&(objectClass=group)(member={0}))";
    private String roleNameAttribute = "cn";
    private String referrals = "follow";

    // Tomcat's config digester calls these based on the XML attribute names above.
    public void setConnectionURL(String v) { this.connectionURL = v; }
    public void setConnectionName(String v) { this.connectionName = v; }
    public void setConnectionPassword(String v) { this.connectionPassword = v; }
    public void setUserBase(String v) { this.userBase = v; }
    public void setUserSearch(String v) { this.userSearch = v; }
    public void setRoleBase(String v) { this.roleBase = v; }
    public void setRoleSearchFilter(String v) { this.roleSearchFilter = v; }
    public void setRoleNameAttribute(String v) { this.roleNameAttribute = v; }
    public void setReferrals(String v) { this.referrals = v; }

    @Override
    public String getName() {
        return "LdapMemberRealm";
    }

    // Required abstract methods from RealmBase. Not used — authenticate()
    // below is fully overridden and does not rely on password comparison
    // or principal caching through these.
    @Override
    protected String getPassword(String username) {
        return null;
    }

    @Override
    protected Principal getPrincipal(String username) {
        return null;
    }

    private DirContext openContext(String principal, String credentials) throws NamingException {
        Hashtable<String, Object> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, connectionURL);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, principal);
        env.put(Context.SECURITY_CREDENTIALS, credentials);
        env.put(Context.REFERRAL, referrals);
        return new InitialDirContext(env);
    }

    private static String escapeFilter(String input) {
        return input.replace("\\", "\\5c")
                    .replace("*", "\\2a")
                    .replace("(", "\\28")
                    .replace(")", "\\29")
                    .replace("\0", "\\00");
    }

    @Override
    public Principal authenticate(String username, String credentials) {
        if (username == null || credentials == null || credentials.isEmpty()) {
            return null;
        }

        DirContext adminCtx = null;
        try {
            // Step 1: bind as the service account, find the user's DN
            adminCtx = openContext(connectionName, connectionPassword);

            SearchControls sc = new SearchControls();
            sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
            sc.setReturningAttributes(new String[]{});

            String filter = userSearch.replace("{0}", escapeFilter(username));
            NamingEnumeration<SearchResult> results = adminCtx.search(userBase, filter, sc);

            if (!results.hasMore()) {
                results.close();
                log.debug("LdapMemberRealm: user not found: " + username);
                return null;
            }
            SearchResult userResult = results.next();
            String userDn = userResult.getNameInNamespace();
            results.close();

            // Step 2: verify the password by binding as the user
            try {
                DirContext userCtx = openContext(userDn, credentials);
                userCtx.close();
            } catch (AuthenticationException authEx) {
                log.debug("LdapMemberRealm: bad credentials for " + username);
                return null;
            }

            // Step 3: resolve roles — same reverse group search confirmed
            // working in standalone testing, run under the service account
            List<String> roles = new ArrayList<>();
            String roleFilter = roleSearchFilter.replace("{0}", userDn);

            SearchControls roleControls = new SearchControls();
            roleControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            roleControls.setReturningAttributes(new String[]{roleNameAttribute});

            NamingEnumeration<SearchResult> roleResults = adminCtx.search(roleBase, roleFilter, roleControls);
            while (roleResults.hasMore()) {
                SearchResult r = roleResults.next();
                Attribute cnAttr = r.getAttributes().get(roleNameAttribute);
                if (cnAttr != null) {
                    roles.add((String) cnAttr.get());
                }
            }
            roleResults.close();

            log.info("LdapMemberRealm: authenticated '" + username + "' with roles " + roles);

            return new GenericPrincipal(username, null, roles);

        } catch (NamingException e) {
            log.error("LdapMemberRealm: LDAP error authenticating '" + username + "'", e);
            return null;
        } finally {
            if (adminCtx != null) {
                try {
                    adminCtx.close();
                } catch (NamingException ignored) {
                }
            }
        }
    }
}
